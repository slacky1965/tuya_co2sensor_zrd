/********************************************************************************************************
 * @file    driver_8278.h
 *
 * @brief   This is the header file for B87
 *
 * @author  Driver & Zigbee Group
 * @date    2021
 *
 * @par     Copyright (c) 2021, Telink Semiconductor (Shanghai) Co., Ltd. ("TELINK")
 *			All rights reserved.
 *
 *          Licensed under the Apache License, Version 2.0 (the "License");
 *          you may not use this file except in compliance with the License.
 *          You may obtain a copy of the License at
 *
 *              http://www.apache.org/licenses/LICENSE-2.0
 *
 *          Unless required by applicable law or agreed to in writing, software
 *          distributed under the License is distributed on an "AS IS" BASIS,
 *          WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *          See the License for the specific language governing permissions and
 *          limitations under the License.
 *
 *******************************************************************************************************/

#pragma once


#include "bsp.h"
#include "register.h"
#include "analog.h"
#include "clock.h"
#include "timer.h"
#include "irq.h"
#include "dfifo.h"
#include "watchdog.h"
#include "dma.h"
#include "aes.h"
#include "gpio.h"
#include "adc.h"
#include "random.h"
#include "pwm.h"
#include "audio.h"
#include "flash.h"
#include "i2c.h"
#include "spi.h"
#include "uart.h"
#include "usbhw.h"
#include "rf_drv.h"
#include "emi.h"
#include "pm.h"
#include "pke_algorithm.h"
#include "flash/flash_type.h"
#include "flash/flash_common.h"
