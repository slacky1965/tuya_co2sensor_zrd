#!/usr/bin/env python3
"""Guard the Bathroom YVX5LH6K datapoint and VOC unit contracts."""

from pathlib import Path
import re


ROOT = Path(__file__).parents[1]
MODEL = (ROOT / "src" / "app_co2sensor_model2.c").read_text(encoding="utf-8")
SIGNATURES = (ROOT / "src" / "app_tuya_datapoint.c").read_text(encoding="utf-8")
VERSION = (ROOT / "src" / "include" / "version_cfg.h").read_text(encoding="utf-8")
MAKEFILE = (ROOT / "makefile").read_text(encoding="utf-8")


def ppm_from_raw_ppb(raw_ppb: int) -> float:
    return (raw_ppb / 1_000_000_000.0) / 0.000001


def main() -> None:
    expected_table = (
        "{DP_TYPE2_ID_02, DP_VAL,  4,    1,  NULL, local_cmd_co2_2}",
        "{DP_TYPE2_ID_12, DP_VAL,  4,    10, NULL, local_cmd_temperature_2}",
        "{DP_TYPE2_ID_13, DP_VAL,  4,    10, NULL, local_cmd_humidity_2}",
        "{DP_TYPE2_ID_15, DP_VAL,  4,    1,  NULL, local_cmd_voc_2}",
        "{DP_TYPE2_ID_16, DP_VAL,  4,    1,  NULL, local_cmd_formaldehyde_2}",
    )
    for row in expected_table:
        assert row in MODEL, f"missing YVX datapoint mapping: {row}"
    assert '"yvx5lh6k"' in SIGNATURES
    assert '"mja3fuja"' not in SIGNATURES
    assert "float attrVoc = (float)*voc / 1000000000.0f;" in MODEL
    assert "data_point_model[DP_IDX_FHYD]" in MODEL
    assert int(re.search(r"#define APP_BUILD\s+0x([0-9A-Fa-f]+)", VERSION).group(1), 16) == 7
    assert "TC32_PREFIX ?= tc32" in MAKEFILE

    for raw_ppb in (1, 3, 5):
        assert abs(ppm_from_raw_ppb(raw_ppb) - raw_ppb / 1000.0) < 1e-12

    print("Bathroom YVX5LH6K datapoints and VOC contract verified")


if __name__ == "__main__":
    main()
